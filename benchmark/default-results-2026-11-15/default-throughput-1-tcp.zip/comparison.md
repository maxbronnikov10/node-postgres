<!-- benchmark-comment -->

## Benchmark: `efbc543` against `efbc543`

Profile: postgresjs.
Same checkout. Base/base2 use pinned Postgres.js; head/head2 use pg.postgres. All actors use four warmed connections, max pipeline 16, prepared statements, identical tagged SQL and checked object/array result shapes.
Controls above 10% make a row inconclusive even when every ratio is faster or slower.

| Scenario | Base q/s | Head q/s | Head / base | Rounds | Noise |
| --- | ---: | ---: | ---: | ---: | ---: |
| tagged point SELECT, sequential :eyes: | 14417 | 13088 | 0.920x (**-8.0%**) | 0.88 to 0.96 | ±6.0% |
| tagged point SELECT, concurrent x16 :eyes: | 53550 | 42182 | 0.787x (**-21.3%**) | 0.77 to 0.81 | ±2.5% |
| tagged 500-row object SELECT, concurrent x16 :eyes: | 9561 | 7889 | 0.823x (**-17.7%**) | 0.82 to 0.83 | ±1.4% |
| tagged 500-row array SELECT, concurrent x16 :eyes: | 9131 | 7561 | 0.829x (**-17.1%**) | 0.82 to 0.84 | ±1.0% |
| tagged 500-row mixed SELECT, concurrent x16 :eyes: | 2014 | 1592 | 0.789x (**-21.1%**) | 0.78 to 0.80 | ±1.8% |
| tagged 1-MiB bytea input, concurrent x2 :trophy: | 239 | 788 | 3.299x (**+229.9%**) | 3.22 to 3.38 | ±5.6% |
| tagged logged UPDATE, concurrent x16 :eyes: | 20358 | 18077 | 0.888x (**-11.2%**) | 0.87 to 0.90 | ±4.1% |

8 rounds of 3s per scenario, each round measuring base, head and a second process of each one after the other, in an order that changes every round. "Head / base" is the median of the per-round ratios and "Rounds" their range. "Noise" is how far base/base and head/head, the same code on both sides, got from 1 in this same run: that is what the machine did, so a row is marked only when the median moved further than that, at least 2%, and every round moved the same way: :eyes: slower, :trophy: faster. Only the ratio is comparable across runs, the absolute rates depend on the runner.

Node v22.22.1, Intel(R) Xeon(R) 6975P-C, 4 cores.
