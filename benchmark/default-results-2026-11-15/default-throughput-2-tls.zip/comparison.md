<!-- benchmark-comment -->

## Benchmark: `efbc543` against `efbc543`

Profile: postgresjs.
Same checkout. Base/base2 use pinned Postgres.js; head/head2 use pg.postgres. All actors use four warmed connections, max pipeline 16, prepared statements, identical tagged SQL and checked object/array result shapes.
Verified TLS 1.3 using the same CA and TLS settings on all actors.
Opaque TCP relay adds 3 ms per direction to both actors.
Controls above 10% make a row inconclusive even when every ratio is faster or slower.

| Scenario | Base q/s | Head q/s | Head / base | Rounds | Noise |
| --- | ---: | ---: | ---: | ---: | ---: |
| tagged point SELECT, sequential | 134 | 133 | 0.999x (-0.1%) | 0.86 to 1.02 | ±19.3% (inconclusive) |
| tagged point SELECT, concurrent x16 | 2227 | 2197 | 0.986x (-1.4%) | 0.98 to 0.99 | ±2.3% |
| tagged 500-row object SELECT, concurrent x16 :eyes: | 1830 | 1770 | 0.966x (**-3.4%**) | 0.96 to 0.99 | ±2.4% |
| tagged 500-row array SELECT, concurrent x16 | 1800 | 1757 | 0.976x (-2.4%) | 0.96 to 0.98 | ±3.0% |
| tagged 500-row mixed SELECT, concurrent x16 :eyes: | 1003 | 919 | 0.916x (**-8.4%**) | 0.90 to 0.93 | ±1.6% |
| tagged 1-MiB bytea input, concurrent x2 :trophy: | 43 | 82 | 1.909x (**+90.9%**) | 1.88 to 1.93 | ±1.7% |
| tagged logged UPDATE, concurrent x16 | 2064 | 2044 | 0.988x (-1.2%) | 0.98 to 0.99 | ±1.3% |

8 rounds of 3s per scenario, each round measuring base, head and a second process of each one after the other, in an order that changes every round. "Head / base" is the median of the per-round ratios and "Rounds" their range. "Noise" is how far base/base and head/head, the same code on both sides, got from 1 in this same run: that is what the machine did, so a row is marked only when the median moved further than that, at least 2%, and every round moved the same way: :eyes: slower, :trophy: faster. Only the ratio is comparable across runs, the absolute rates depend on the runner.

Node v22.22.1, Intel(R) Xeon(R) 6975P-C, 4 cores.
