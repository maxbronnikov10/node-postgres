<!-- benchmark-comment -->

## Benchmark: `efbc543` against `efbc543`

Profile: postgresjs.
Same checkout. Base/base2 use pinned Postgres.js; head/head2 use pg.postgres. All actors use four warmed connections, max pipeline 16, prepared statements, identical tagged SQL and checked object/array result shapes.
Controls above 10% make a row inconclusive even when every ratio is faster or slower.

| Scenario | Base q/s | Head q/s | Head / base | Rounds | Noise |
| --- | ---: | ---: | ---: | ---: | ---: |
| tagged point SELECT, sequential :eyes: | 4889 | 4328 | 0.887x (**-11.3%**) | 0.87 to 0.89 | ±2.3% |
| tagged point SELECT, concurrent x16 :eyes: | 17647 | 15764 | 0.896x (**-10.4%**) | 0.87 to 0.91 | ±1.6% |
| tagged 500-row object SELECT, concurrent x16 :eyes: | 5109 | 4413 | 0.861x (**-13.9%**) | 0.84 to 0.89 | ±3.6% |
| tagged 500-row array SELECT, concurrent x16 :eyes: | 4817 | 4291 | 0.889x (**-11.1%**) | 0.88 to 0.90 | ±2.0% |
| tagged 500-row mixed SELECT, concurrent x16 :eyes: | 986 | 828 | 0.840x (**-16.0%**) | 0.82 to 0.85 | ±2.2% |
| tagged 1-MiB bytea input, concurrent x2 | 162 | 513 | 3.176x (+217.6%) | 3.09 to 3.40 | ±12.4% (inconclusive) |
| tagged logged UPDATE, concurrent x16 :eyes: | 8368 | 7783 | 0.933x (**-6.7%**) | 0.92 to 0.98 | ±5.7% |

8 rounds of 3s per scenario, each round measuring base, head and a second process of each one after the other, in an order that changes every round. "Head / base" is the median of the per-round ratios and "Rounds" their range. "Noise" is how far base/base and head/head, the same code on both sides, got from 1 in this same run: that is what the machine did, so a row is marked only when the median moved further than that, at least 2%, and every round moved the same way: :eyes: slower, :trophy: faster. Only the ratio is comparable across runs, the absolute rates depend on the runner.

Node v22.22.1, AMD EPYC 7763 64-Core Processor, 4 cores.
