<!-- benchmark-comment -->

## Benchmark: `efbc543` against `2db1b54`

Profile: sql-compile.
Before/after SQL-tag compiler. Four warmed connections, depth 16, prepared statements, identical SQL and checked results. Two independent processes per checkout measure same-code noise.
Controls above 10% make a row inconclusive even when every ratio is faster or slower.

| Scenario | Base q/s | Head q/s | Head / base | Rounds | Noise |
| --- | ---: | ---: | ---: | ---: | ---: |
| tagged point SELECT, concurrent x16 | 15447 | 15894 | 1.024x (+2.4%) | 1.01 to 1.04 | ±2.7% |

8 rounds of 3s per scenario, each round measuring base, head and a second process of each one after the other, in an order that changes every round. "Head / base" is the median of the per-round ratios and "Rounds" their range. "Noise" is how far base/base and head/head, the same code on both sides, got from 1 in this same run: that is what the machine did, so a row is marked only when the median moved further than that, at least 2%, and every round moved the same way: :eyes: slower, :trophy: faster. Only the ratio is comparable across runs, the absolute rates depend on the runner.

Node v22.22.1, AMD EPYC 7763 64-Core Processor, 4 cores.
