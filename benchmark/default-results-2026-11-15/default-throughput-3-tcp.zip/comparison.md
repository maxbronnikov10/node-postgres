<!-- benchmark-comment -->

## Benchmark: `efbc543` against `efbc543`

Profile: postgresjs.
Same checkout. Base/base2 use pinned Postgres.js; head/head2 use pg.postgres. All actors use four warmed connections, max pipeline 16, prepared statements, identical tagged SQL and checked object/array result shapes.
Controls above 10% make a row inconclusive even when every ratio is faster or slower.

| Scenario | Base q/s | Head q/s | Head / base | Rounds | Noise |
| --- | ---: | ---: | ---: | ---: | ---: |
| tagged point SELECT, sequential | 14999 | 13827 | 0.911x (-8.9%) | 0.89 to 1.01 | ±7.0% |
| tagged point SELECT, concurrent x16 :eyes: | 56067 | 43317 | 0.773x (**-22.7%**) | 0.77 to 0.79 | ±1.7% |
| tagged 500-row object SELECT, concurrent x16 :eyes: | 11549 | 9155 | 0.792x (**-20.8%**) | 0.78 to 0.80 | ±1.8% |
| tagged 500-row array SELECT, concurrent x16 :eyes: | 10979 | 8705 | 0.793x (**-20.7%**) | 0.78 to 0.80 | ±1.7% |
| tagged 500-row mixed SELECT, concurrent x16 :eyes: | 2056 | 1619 | 0.788x (**-21.2%**) | 0.78 to 0.80 | ±2.1% |
| tagged 1-MiB bytea input, concurrent x2 :trophy: | 240 | 796 | 3.301x (**+230.1%**) | 3.23 to 3.37 | ±6.0% |
| tagged logged UPDATE, concurrent x16 :eyes: | 20465 | 18496 | 0.903x (**-9.7%**) | 0.84 to 0.91 | ±4.0% |

8 rounds of 3s per scenario, each round measuring base, head and a second process of each one after the other, in an order that changes every round. "Head / base" is the median of the per-round ratios and "Rounds" their range. "Noise" is how far base/base and head/head, the same code on both sides, got from 1 in this same run: that is what the machine did, so a row is marked only when the median moved further than that, at least 2%, and every round moved the same way: :eyes: slower, :trophy: faster. Only the ratio is comparable across runs, the absolute rates depend on the runner.

Node v22.22.1, Intel(R) Xeon(R) 6975P-C, 4 cores.
