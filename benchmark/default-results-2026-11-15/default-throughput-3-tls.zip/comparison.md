<!-- benchmark-comment -->

## Benchmark: `efbc543` against `efbc543`

Profile: postgresjs.
Same checkout. Base/base2 use pinned Postgres.js; head/head2 use pg.postgres. All actors use four warmed connections, max pipeline 16, prepared statements, identical tagged SQL and checked object/array result shapes.
Verified TLS 1.3 using the same CA and TLS settings on all actors.
Opaque TCP relay adds 3 ms per direction to both actors.
Controls above 10% make a row inconclusive even when every ratio is faster or slower.

| Scenario | Base q/s | Head q/s | Head / base | Rounds | Noise |
| --- | ---: | ---: | ---: | ---: | ---: |
| tagged point SELECT, sequential | 137 | 136 | 1.000x (-0.0%) | 0.98 to 1.03 | ±14.7% (inconclusive) |
| tagged point SELECT, concurrent x16 | 2028 | 1985 | 0.981x (-1.9%) | 0.97 to 0.99 | ±2.7% |
| tagged 500-row object SELECT, concurrent x16 :eyes: | 1586 | 1531 | 0.964x (**-3.6%**) | 0.95 to 0.98 | ±1.2% |
| tagged 500-row array SELECT, concurrent x16 :eyes: | 1577 | 1521 | 0.966x (**-3.4%**) | 0.95 to 0.99 | ±2.3% |
| tagged 500-row mixed SELECT, concurrent x16 :eyes: | 636 | 587 | 0.917x (**-8.3%**) | 0.89 to 0.93 | ±2.8% |
| tagged 1-MiB bytea input, concurrent x2 :trophy: | 40 | 78 | 1.948x (**+94.8%**) | 1.89 to 2.01 | ±6.5% |
| tagged logged UPDATE, concurrent x16 | 1722 | 1678 | 0.976x (-2.4%) | 0.97 to 0.99 | ±3.5% |

8 rounds of 3s per scenario, each round measuring base, head and a second process of each one after the other, in an order that changes every round. "Head / base" is the median of the per-round ratios and "Rounds" their range. "Noise" is how far base/base and head/head, the same code on both sides, got from 1 in this same run: that is what the machine did, so a row is marked only when the median moved further than that, at least 2%, and every round moved the same way: :eyes: slower, :trophy: faster. Only the ratio is comparable across runs, the absolute rates depend on the runner.

Node v22.22.1, AMD EPYC 7763 64-Core Processor, 4 cores.
